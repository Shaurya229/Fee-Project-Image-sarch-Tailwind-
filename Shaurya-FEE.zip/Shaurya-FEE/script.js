const apiKey = "YVaxCx61QHKkaf4fl8FfLonouylw89l729wKxAIAHt6cwCyF7RYP7ezP"; // Replace with your Pexels API key
const searchInput = document.getElementById("searchInput");
const searchButton = document.getElementById("searchButton");
const imageContainer = document.getElementById("imageContainer");

searchInput.addEventListener("input", debounce(searchImages, 500));
searchButton.addEventListener("click", searchImages);

// Load random images on page load
window.addEventListener("load", loadRandomImages);

function debounce(func, delay) {
  let timeout;
  return function (...args) {
    const context = this;
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(context, args), delay);
  };
}

async function searchImages() {
  const query = searchInput.value.trim();
  if (!query) {
    loadRandomImages();
  } else {
    try {
      const response = await fetch(
        `https://api.pexels.com/v1/search?query=${encodeURIComponent(query)}`,
        {
          headers: {
            Authorization: apiKey,
          },
        }
      );
      const data = await response.json();
      displayImages(data.photos);
    } catch (error) {
      console.error("Error fetching images:", error);
    }
  }
}

async function loadRandomImages() {
  try {
    const response = await fetch("https://api.pexels.com/v1/curated", {
      headers: {
        Authorization: apiKey,
      },
    });
    const data = await response.json();
    displayImages(data.photos.slice(0, 20)); // Display only the first 20 images
  } catch (error) {
    console.error("Error fetching images:", error);
  }
}

function displayImages(photos) {
  imageContainer.innerHTML = "";
  photos.forEach((photo) => {
    const img = document.createElement("img");
    img.src = photo.src.medium;
    img.alt = photo.photographer;
    img.classList.add("rounded");
    imageContainer.appendChild(img);
  });
}
